package com.jsp.coedify;

public class EvenNodd {

	public static void main(String[] args) 
	{
		int even=0;
		int odd=0;
		int a[]= {2,1,4, 5, 3, 13, 11, 6};
		for(int i=0;i<a.length;i++)
		{
			if(a[i]%2==0)
			{
				even=even+a[i];
			}
			else
			{
				odd=odd+a[i];
			}
		}
		System.out.println("Total of even Numbers :"+even);
		System.out.println("Total of odd Numbers :"+odd);
	}

}
