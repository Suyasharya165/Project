package com.jsp.coedify;

public class LeapYear 
{
	public  boolean leapYear(int year)
	{
		if((year%400==0) || (year%4==0 && year%100 !=0))
		{
			return true;
		}
		else 
		{
			return false;
		}
	}

	public static void main(String[] args) 
	{
		LeapYear y = new LeapYear() ;
		System.out.println(y.leapYear(2010));
	}

}
