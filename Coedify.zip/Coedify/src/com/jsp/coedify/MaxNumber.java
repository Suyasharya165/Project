package com.jsp.coedify;

public class MaxNumber {

	public static void main(String[] args) 
	{
		int a[]= {23,54,56,12,8,93};
		int temp=0;
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<=a.length-1;j++)
			{
				if(a[i]<a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		//for(int i=0;i<a.length;i++)
		{
			System.out.println(a[0]);
		}
	}
}
