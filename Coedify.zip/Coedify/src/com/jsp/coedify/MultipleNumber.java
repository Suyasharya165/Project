package com.jsp.coedify;

import java.util.Scanner;

public class MultipleNumber {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("input number");
		int n= sc.nextInt();
		for(int i=1;i<=10;i++)
		{
			System.out.println(n+"x"+(i)+"="+n*i);
		}
	}

}
