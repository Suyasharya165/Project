package com.jsp.coedify;

public class MultipleOf3N5 
{
	public static int sum(int n)
	{
		if(n<0)
		{
			return -1;
		}
		int result=0;
		
		for(int i=0;i<=n;i++)
		{
			if(i%3==0 || i%5==0)
			{
				result=result+i;
			}
		}	
		return result;
	}
	
	public static void main(String[] args) 
	{
		int result=sum(-10);
		if(result==-1)
		{
			System.out.println("invaild input");
		}
		System.out.println("Total of Nth place is :"+result);
	}
}

