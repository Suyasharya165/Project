package com.jsp.coedify;

public class OneToEnd {

	public static void main(String[] args) 
	{
		int n=10;
		int result=0;
		for(int i=1;i<=n;i++)
		{
			result=result+i;
		}
		System.out.println("result : "+result);
	}

}
