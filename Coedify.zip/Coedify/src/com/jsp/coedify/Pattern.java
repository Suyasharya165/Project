package com.jsp.coedify;

public class Pattern 
{
	public static void main(String[] args) 
	{
		int n=3;
		for(char i='A';i<='C';i++)
		{
			for(char j='A';j<=i;j++)
			{
				System.out.print(i+" ");
			}
			System.out.println("");
		}
		
		for(int i=1;i<=2*n;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(i+" ");
			}
			System.out.println();
		}	
	}
}
