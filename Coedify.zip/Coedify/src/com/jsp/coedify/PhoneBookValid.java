package com.jsp.coedify;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PhoneBookValid {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	      System.out.println("Enter your name: ");
	      String name = sc.nextLine();
	      
	      //Regular expression to match M or, F or, O
	      String regex = "M|F|O";
	       Scanner sc1 = new Scanner(System.in);
	       System.out.println("Enter students gender:");
	       String name1 = sc1.nextLine();
	       Pattern p = Pattern.compile(regex);
	       Matcher m = p.matcher(name1);
	       if(m.matches()) {
	          System.out.println();
	       } else {
	          System.out.println("Wrong Input");
	       }
	       
	     //Regular expression to mob
	       System.out.println("Enter your Phone number: ");
	       String phone = sc.next();
	       //Regular expression to accept valid phone number
	       String regex1 = "\\d{10}";
	       //Creating a pattern object
	       Pattern pattern = Pattern.compile(regex1);
	       //Creating a Matcher object
	       Matcher matcher = pattern.matcher(phone);
	       //Verifying whether given phone number is valid
	       if(matcher.matches()) {
	          System.out.println("Given phone number is valid");
	       } else { 
	          System.out.println("Given phone number is not valid");
	       }
	          
	          //Regular expression to email
	      System.out.println("Enter your email id: ");
	      String phone1 = sc1.next();
	      //Regular expression to accept valid email id
	      String regex11 = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$";
	      //Creating a pattern object
	      Pattern pattern1 = Pattern.compile(regex11);
	      //Creating a Matcher object
	      Matcher matcher1 = pattern1.matcher(phone1);
	      //Verifying whether given phone number is valid
	      if(matcher1.matches()) {
	         System.out.println("Given email id is valid");
	      } else {
	         System.out.println("Given email id is not valid");
	      }
	       
	}

}