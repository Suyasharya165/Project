package com.jsp.coedify;

public class PrimeNumber {

	public static void main(String[] args) 
	{
		int i=0;
		int j=0;
		String primeNo = "";
		for( i=1;i<=100;i++)
		{
			int counter=0;
			for(j=i;j>=1;j--)
			{
				if(i%j==0)
				{
					counter= counter+1;
				}
			}
			if(counter==2)
			{
				primeNo=primeNo+i+" ";
			}
			
		}
		System.out.println("prime no from 1 to 100 :");
		System.out.println(primeNo);
	}
}
