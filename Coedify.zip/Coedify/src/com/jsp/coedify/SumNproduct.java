package com.jsp.coedify;

public class SumNproduct {

	public static void main(String[] args) 
	{
		int n=6;
		int sum=0;
		int product=1;
		for(int i=1;i<=n;i++)
		{
			sum=sum+i;
			product=product*i;
		}
		System.out.println(sum);
		System.out.println(product);
	}
}
