package com.jsp.collections;

public class AddOdd {

	public static void main(String[] args) 
	{
		int a[]= {1,2,3,4,5,6,7,8};
	    int[] a1=new int[a.length-1/2];
		int e=0;
		int o =0;
		int sum =0;
		
		System.out.println("even position..............");
		for(int i=0;i<a.length-3;i+=2)
		{
			sum = a[i]+a[i+2];
			a1[e] = sum;
			System.out.println(a1[e]);
			e++;
			
		}
		
		System.out.println("odd position..............");
		for(int i=1;i<a.length-2;i+=2)
		{
			sum = a[i]+a[i+2];
			a1[o] = sum;
			System.out.println(a1[o]);
			o++;
			
		}
	}
}
