package com.jsp.collections;

import java.util.Collections;

public class ArrayList {

	public static void main(String[] args) 
	{
		java.util.ArrayList<Integer> list = new java.util.ArrayList<Integer>();
		
		list.add(90);
		list.add(80);
		list.add(50);
		list.add(30);
		list.add(10);
		list.add(80);
		list.add(60);
		list.add(40);
		list.add(20);
		
		System.out.println("The content of ArrayList is"+list+"");
		System.out.println();
		
		list.remove(5);
		list.remove(2);
		System.out.println("The content of ArrayList is"+list+" ");
		System.out.println();
		if(list.contains(90))
		{
			System.out.println("Value 90 is present");
		}
		else
		{
			System.out.println("value is not present");
		}
		System.out.println();
		int elementAt5 = list.get(5);
		System.out.println("Element at index 5 is :"+elementAt5);
		System.out.println();
		Collections.sort(list);
		System.out.println("After sorting of the list:"+list+" ");
		Collections.reverse(list);
		System.out.println();
		System.out.println("After sorting of the list:"+list+" ");

	}

}
