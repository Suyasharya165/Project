package com.jsp.collections;

import java.util.Collections;

public class Cyclically {

	public static void main(String[] args) 
	{
		int a[] = new int[]{1,2,3,4,5};
		int n=3;
		
		for(int i=0; i<n;i++)
		{
			int j, last;
			last=a[a.length-1];
			
		for(j=a.length;j>0;j--)
		{
			a[i]=a[j-1];
		}
		a[0]=last;
		
		System.out.println("element shift"+a[i]);
		}
	}

}
