package com.jsp.collections;

public class LinkedList {

	public static void main(String[] args) 
	{
		java.util.LinkedList<String> list = new java.util.LinkedList<String>();
		list.add("i");
		list.add("finally");
		//list.add("got");
		list.add("got");
		list.add("a");
		list.add("job");
		System.out.println("List after insertion of value:"+list+" ");
		System.out.println();
		//list.remove(3);
		System.out.println("List after remove operation"+list+" ");
		System.out.println();
		list.add("Google");
		System.out.println("Final LinkedList :");
		for(int i=0;i<list.size()-1;i++)
		{
			System.out.println(list.get(i)+" ");
		}
		System.out.println();
	}
}
