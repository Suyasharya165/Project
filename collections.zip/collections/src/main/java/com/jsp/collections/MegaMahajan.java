package com.jsp.collections;

import java.util.Arrays;

public class MegaMahajan {

	public static void main(String[] args) 
	{
		double abc[]= {30,1.75,4,3.86};
		double def[] = {25,1.75,3.75,4.3};
		double ghi[]= {28,1.8,4.25,5};
	
		double lead =0;
		double tender =0;
		double project=0;
		double vendor=0;
		
		
		lead= abc[0]+def[0]+ghi[0];
		
		tender = abc[1]+def[1]+ghi[1];
		
		project= abc[2]+def[2]+ghi[2];
		
		vendor= abc[3]+def[3]+ghi[3];
		
	
		
		double minvalue[]= {lead,tender,project,vendor};		
			
		
		Arrays.sort(minvalue);
		
		
		
		System.out.println("MR.mahajan,you should award the tender to ABC:-"
		+minvalue[minvalue.length/2]);
		
		
		

	}

}
