package com.jsp.collections;

import java.util.Collections;

public class MissingNumber 
{
	public static void main(String[] args)
	{
		//int nxt = 0;
		int a[]= {1,2,3,4,6,7,8};
		for(int i=0;i<a.length-1;i++)
		{
			if(a[i+1]-a[i]>1) 
			{
				System.out.println("Missing Number"+a[i]+1);
			}
	    }
    }
}
