package com.jsp.collections;

import java.util.Collections;

public class ReverseString {

	public static void main(String[] args) 
	{
	//	java.util.ArrayList<String> list = new java.util.ArrayList<String>();
		
//		list.add("k");
//		list.add("n");
//		list.add("o");
//		list.add("w");
//		list.add("l");
//		list.add("e");
//		list.add("d");
//		list.add("g");
//		list.add("e");
//		Collections.reverse(list);
//		System.out.println(list);
		
		String str = "knowledge";
		System.out.println(str.substring(4, str.length()).concat((String) str.subSequence(0, 4)));
		

	}

}
