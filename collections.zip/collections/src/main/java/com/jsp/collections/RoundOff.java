package com.jsp.collections;

import java.util.Iterator;

public class RoundOff 
{
	public static void main(String[] args) 
	{
		int a[] = {76,50,35,11,90,40};
		
		for(int i=0;i<a.length;i++)
		{
			if(a[i]%5==3)
			{
				a[i]=a[i]+2;
			}
			if(a[i]%5==4)
			{
				a[i]=a[i]+1;
			}
		}
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
	}
}
