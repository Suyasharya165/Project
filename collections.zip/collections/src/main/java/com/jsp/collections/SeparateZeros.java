package com.jsp.collections;

import java.util.Collections;

public class SeparateZeros {

	public static void main(String[] args) 
	{
	java.util.ArrayList<Integer> list = new java.util.ArrayList<Integer>();
		
		list.add(12);
		list.add(0);
		list.add(7);
		list.add(0);
		list.add(8);
		list.add(0);
		list.add(3);
		Collections.sort(list);
		System.out.println(list);
		

	}

}
