package com.jsp.collections;

public class Stack {

	public static void main(String[] args) 
	{
		
	}

}
