package com.jsp.collections;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

public class VendorTender {

	public static void main(String[] args) 
	{
		String name[]= {"ABC","DEF","GHI"};
		
		int lead[]= {30,25,28};
		double value[]= {1.75,1.95,1.8};
		double duration[]= {4.0,3.75,4.25};
		double rating[]= {3.85,4.3,5.0};
		
//		Arrays.sort(lead);
//		Arrays.sort(value);
//		Arrays.sort(duration);
//		Arrays.sort(rating);
		int flag1=0;
		int flag2=0;
		int flag3=0;
		if(lead[0]>lead[1])
		{
			flag1++;
		}
		else if(lead[1]>lead[2])
		{
			flag2++;
		}
		else
		{
			flag3++;
		}
		if(flag1==1)
		{
			System.out.println("right tender goes to ABC");
		}
		else if (flag2==1)
		{
			System.out.println("rigth tender goes to DEF");
		}
		else 
		{
			System.out.println("rigth tender goes to GHI");
		}


	}

}
