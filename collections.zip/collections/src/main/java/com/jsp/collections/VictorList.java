package com.jsp.collections;

import java.util.Collection;
import java.util.Collections;

public class VictorList {

	public static void main(String[] args) 
	{
		java.util.Vector<Integer> list = new java.util.Vector<Integer>();
		list.add(30);
		list.add(40);
		list.add(50);
		list.add(60);
		list.add(10);
		list.add(20);
		list.add(90);
		list.add(80);
		list.add(80);
		System.out.println("The contents of VectorList is:"+list+"");
		System.out.println();
		list.remove(5);
		System.out.println("The contents of vectorList:"+list+"");
		System.out.println();
		Collections.sort(list);
		System.out.println("After sorting of the list:"+list+"");
		System.out.println();
		list.clear();
		System.out.println("Final List:"+list+" ");
		System.out.println();
	}

}
