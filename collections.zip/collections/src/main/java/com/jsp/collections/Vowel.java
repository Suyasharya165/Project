package com.jsp.collections;

public class Vowel 
{
	public static void main(String[] args) 
	{
				int vowel=0,count=0;
				String str = "my name is suyash";
				str.toLowerCase();
				for (int i=0;i<str.length();i++ ) 
				{
					if ((str.charAt(i)=='a') || (str.charAt(i)=='e') || ( str.charAt(i)=='i') || ( str.charAt(i)=='o') || ( str.charAt(i)=='u'))
					{
						vowel++;
					}
					else if (str.charAt(i)>='a' && str.charAt(i)<='z')
					{
						count++;
					}
				}
				System.out.println(vowel);
				System.out.println(count);
	}
		

}


