package snake; 
import java.util.*;
import snake.Patient.Doctor;

import java.io.*; 
public class HospitalProcess { 
	public static final String availability = null;
	static ArrayList<Patient> arl = new ArrayList<Patient>(); 
	static ArrayList<Doctor> arl1 = new ArrayList<Doctor>(); 
	public static void main(String[] args) throws IOException { 
		char l='i'; 
		Patient p1 = new Patient(1,"Raja",  40, 659856245, 'm', "Fever", "thyroixin"); 
		arl.add(p1); 
		Patient p2 = new Patient(2,"Rani",  45, 959862454,'f', "Cough", "combiflam"); 
		arl.add(p2); 
		Patient p3 = new Patient(3, "James",  56, 959837898, 'm', "Cold", "paracitmala"); 
		arl.add(p3); 
		do { 
			Patient p = new Patient(); 
			System.out.println("Enter 1 to add a Patient \n 2 to update Patient details \n 3 to remove "
					+ "Patient details \n 4 to display Patient details"); 
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
			int choice = Integer.parseInt(br.readLine()); 
			switch(choice) { 
			case 1: 
				p.registerPatient(); 
				System.out.println("Patient Registered Successfully !!!"); 
				p.showPatientDetails(); 
				break; 
				case 2: 
				p.showPatientDetails(); 
				p.updatePatientDetails(); 
				break; 
				case 3: 
					p.removeInactivePatient(); 
					break; 
					case 4: 
						Collections.sort(arl); 
						p.showPatientDetails(); 
						break;
						default: 
							System.out.println("Patient does not exist with the entered ID"); 
							System.out.println("Try again"); 
							break; 
							} 
			System.out.println("Do you want to continue selecting options (y/n):"); 
			l=(char)
					br.read(); 
			}
		while(l=='y'); 
			
	
	//doctor
	char l1='j'; 
	Doctor d1 =  p1.new Doctor(9,"ghansyam",958479683,"covid","corolin");
	arl1.add(d1);
	Doctor d2 = p1.new Doctor(2,"Rani", 959862454, "Cough", "combiflam"); 
	arl1.add(d2); 
	Doctor d3 = p1.new Doctor(3, "James", 959837898, "Cold", "paracitmala"); 
	arl1.add(d3);
	do { 
		Doctor d = p1.new Doctor(); 
		System.out.println("Enter 1 to add a Doctor \n 2 to update Doctor details \n 3 to remove "
				+ "Doctor details \n 4 to display Doctor details"); 
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
		int choice = Integer.parseInt(br.readLine()); 
		switch(choice) { 
		case 1: 
			d.registerDoctor(); 
			System.out.println("Doctor Registered Successfully !!!"); 
			d.showDoctorDetails(); 
			break; 
			case 2: 
			d.showDoctorDetails(); 
			d.updateDoctorDetails(); 
			break; 
			case 3: 
				//d.removeInactiveDoctor(); 
				break; 
				case 4: 
					Collections.sort(arl); 
					d.showDoctorDetails(); 
					break;
					default: 
						System.out.println("Doctor does not exist with the entered ID"); 
						System.out.println("Try again"); 
						break; 
						} 
		System.out.println("Do you want to continue selecting options (y/n):"); 
		l1=(char)
				br.read(); 
		}
	while(l1=='y'); 
		}
	/*End of main() method */ 
	
}

/***** End of HospitalProcess class *******/ 
/**** Patient class to implement operations *******/ 
class Patient implements Comparable<Patient> { 
	int patientID; 
	String patientName; 
	int age; 
	int phone_no;
	char patientGender; 
	String patientCondition; 
	String prescripation; 
	HospitalProcess hm = new HospitalProcess(); 
	Patient() {} 
	public int compareTo(Patient p) 
	{ 
		return this.patientID = p.patientID; 
		} 
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
	Patient(int patientID,String patientName,int age,int phone_no,char patientGender,String patientCondition, 
			String prescripation) 
	{ 
		this.patientID=patientID; 
		this.patientName=patientName; 
		this.age=age; 
		this. phone_no= phone_no;
		this.patientGender=patientGender; 
		this.patientCondition=patientCondition; 
		this.prescripation = prescripation; 
		} 

	void registerPatient()throws IOException {
	//function to insert new patient records 
	 Patient pr = new Patient(); 
	 @SuppressWarnings("static-access") 
	 int patientID= hm.arl.size(); 
	 pr.patientID = patientID+1; 
	 System.out.println("Enter Patient name:"); 
	 pr.patientName = br.readLine(); 
	 System.out.println("Enter Patient Age:"); 
	 pr.age = Integer.parseInt(br.readLine()); 
	 System.out.println("Enter Patient Phone_no:"); 
	 pr.phone_no = Integer.parseInt(br.readLine()); 
	 System.out.println("Enter Patient Gender:"); 
	 String temp = br.readLine(); 
	 pr.patientGender =temp.charAt(0); 
	 System.out.println("Enter Patient Condition:"); 
	 pr.patientCondition = br.readLine(); 
	 System.out.println("Enter Patient Prescripation:"); 
	 pr.prescripation = br.readLine(); 
     //pr.prescripation = hm.prescripation; 
	 hm.arl.add(pr); 
	 } 
	@SuppressWarnings("static-access") void removeInactivePatient() throws IOException {
	//function to remove patient records 
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
	System.out.println("Enter Patient ID:"); 
	int id1 = Integer.parseInt(br.readLine()); 
	int flag=0; 
    int flag2=0; 
	for(int i=0; i<hm.arl.size(); i++) 
	{ 
		if(id1 != hm.arl.get(i).patientID) 
		{ 
			flag=0; 
			} 
		else if(id1 == hm.arl.get(i).patientID) { 
			prescripation = hm.arl.get(i).prescripation; 
			flag=1; 
			if(prescripation == prescripation) { 
				hm.arl.remove(i); 
				System.out.println("Patient deleted as his validity expired");
				flag2=1; 
				} else{
					flag2=0; 
					} 
			} 
		} 
	if((flag) == 0)
				{ 
					System.out.println("Patient with the entered ID does not exist"); 
					} 
				if(flag2==0) { 
					System.out.println("Patient has still days left before his appointment expires"); 
			}
			} 
	//Function to update patient records/ 
	void updatePatientDetails() throws IOException { 
		char l='n'; 
		Patient p2 = new Patient(patientID, patientName,  age, phone_no, patientGender, patientCondition,
				prescripation); 
		do{ 
			System.out.println("Enter patient ID you want to update:"); 
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
			int idnum = Integer.parseInt(br.readLine()); 
			for(int i=0; i<hm.arl.size(); i++) { 
				if(idnum == hm.arl.get(i).patientID) { 
					System.out.println("Enter 1 to change patient's name \n 2 to change patient's address \n 3 to change patient's age \n 4 to change patient's illness \n 5 to change registration fees along with the medical expenses"); 
					int ch = Integer.parseInt(br.readLine()); 
					switch(ch) { 
					case 1: 
						System.out.println("Enter new patient's name:"); 
						p2.patientName = br.readLine();
						p2.patientID= hm.arl.get(i).patientID; 
						p2.age=hm.arl.get(i).age; 
						p2.phone_no=hm.arl.get(i).phone_no; 
						p2.patientGender=hm.arl.get(i).patientGender;
						p2.patientCondition = hm.arl.get(i).patientCondition;
						p2.prescripation = hm.arl.get(i).prescripation; hm.arl.set(i,p2); 
						System.out.println("Patient updated !!!"); 
						break; 
					case 2: 
						System.out.println("Enter new Patient age:"); 
						p2.age = Integer.parseInt(br.readLine()); 
						p2.patientID = hm.arl.get(i).patientID; 
						p2.patientName = hm.arl.get(i).patientName;  
						p2.patientGender = hm.arl.get(i).patientGender; 
						p2.patientCondition = hm.arl.get(i).patientCondition;  
						p2.prescripation= hm.arl.get(i).prescripation; 
						hm.arl.set(i,p2); 
						System.out.println("Patient updated !!!"); 
						break; 
							case 3: 
								System.out.println("Enter new Patient Phone_no:"); 
								p2.age = Integer.parseInt(br.readLine()); 
								p2.patientID = hm.arl.get(i).patientID; 
								p2.patientName = hm.arl.get(i).patientName;  
								p2.patientGender = hm.arl.get(i).patientGender; 
								p2.patientCondition = hm.arl.get(i).patientCondition;  
								p2.prescripation= hm.arl.get(i).prescripation; 
								hm.arl.set(i,p2); 
								System.out.println("Patient updated !!!"); 
								break; 
								case 4: 
									System.out.println("Enter new Patient condition:");
									p2.age = hm.arl.get(i).age; 
									p2.patientID= hm.arl.get(i).patientID; 
									p2.patientName = hm.arl.get(i).patientName; 
									p2.patientGender = hm.arl.get(i).patientGender; 
									p2.patientCondition = br.readLine();
									p2.prescripation = hm.arl.get(i).prescripation; 
									hm.arl.set(i,p2); 
									System.out.println("Patient updated !!!"); 
									break; 
									case 5: 
										System.out.println("Enter new Patient Prescripation:"); 
										p2.age = hm.arl.get(i).age; 
										p2.patientID = hm.arl.get(i).patientID; 
										p2.patientName = hm.arl.get(i).patientName;
										p2.patientGender = hm.arl.get(i).patientGender; 
										p2.patientCondition = hm.arl.get(i).patientCondition; 
										p2.prescripation = hm.arl.get(i).prescripation;
										hm.arl.set(i,p2); 
										System.out.println("Patient details updated !!!"); 
										break; 
										default: 
											System.out.println("Invalid choice."); 
											break;
											} 
					/*End of switch block */ 
					
					}
				/*End of if block */ 
				}
			/*End of for block */ 
			System.out.println("Do you want to continue updating (y/n):"); 
			l=(char)br.read(); 
			}
		while(l=='y'); 
		/*End of do-while block */ 
		}
	/* Function to display patients details*/ 
	void showPatientDetails() 
	{ 
		System.out.println("patient-ID \t Patient-Name \t\t Age  \t Phone_No \t Gender \t Condition  \t Prescripation"); 
		for(int i=0; i<hm.arl.size(); i++) { 
			System.out.println(hm.arl.get(i).patientID + " \t\t "+hm.arl.get(i).patientName+" \t\t "
					+ " \t "+hm.arl.get(i).age+ " \t "+hm.arl.get(i).phone_no+"  \t "+hm.arl.get(i).patientGender+" "
							+ "\t "+hm.arl.get(i).patientCondition+" \t\t "
									+ "\t "+hm.arl.get(i).prescripation); } } 
/*** End of Patient class ******/

              /**** Doctor class to implement operations *******/
class Doctor implements Comparable<Doctor> { 
	int doctorID;
	String doctorName;  
	int phone_no; 
	String specialization; 
	String availability; 
	HospitalProcess hm = new HospitalProcess(); 
	Doctor() {} 
	public int compareTo(Doctor d) 
	{ 
		return this.doctorID = d.doctorID; 
		} 
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
	Doctor(int doctorID,String doctorName,int phone_no,String specialization, String availability) 
	{ 
		this.doctorID=doctorID; 
		this.doctorName=doctorName; 
		this.phone_no=phone_no; 
		this.specialization=specialization;
		this.availability=availability; 
		} 

	void registerDoctor()throws IOException {
	//function to insert new patient records 
	 Doctor dr = new Doctor(); 
	 @SuppressWarnings("static-access") 
	 int doctorID= hm.arl1.size(); 
	 dr.doctorID = doctorID+1; 
	 System.out.println("Enter Doctor Name:"); 
	 dr.doctorName = br.readLine(); 
	 System.out.println("Enter Doctor Phone_no:"); 
	 dr.phone_no = Integer.parseInt(br.readLine()); 
	 System.out.println("Enter Doctor Specilization:"); 
	 String temp = br.readLine(); 
	 dr.specialization = br.readLine(); 
	 System.out.println("Enter Doctor Availability:"); 
	 dr.availability = hm.availability; 
	 hm.arl1.add(dr); 
	 } 
	@SuppressWarnings("static-access") void removeInactivePatient() throws IOException {
	//function to remove patient records 
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
	System.out.println("Enter Doctor ID:"); 
	int id1 = Integer.parseInt(br.readLine()); 
	int flag=0; 
    int flag2=0; 
	for(int j=0; j<hm.arl1.size(); j++) 
	{ 
		if(id1 != hm.arl1.get(j).doctorID) 
		{ 
			flag=0; 
			} 
		else if(id1 == hm.arl1.get(j).doctorID) { 
			availability = hm.arl1.get(j).availability; 
			flag=1; 
			if(availability == availability) { 
				hm.arl1.remove(j); 
				System.out.println("Doctor deleted as his validity expired");
				flag2=1; 
				} else{
					flag2=0; 
					} 
			} 
		} 
	if((flag) == 0)
				{ 
					System.out.println("Doctor with the entered ID does not exist"); 
					} 
				if(flag2==0) { 
					System.out.println("Doctor has still days left before his appointment expires"); 
			}
			} 
	//Function to update doctor records/ 
	void updateDoctorDetails() throws IOException { 
		char l1='n'; 
		Doctor d2 = new Doctor(doctorID, doctorName, phone_no, specialization, availability); 
		do{ 
			System.out.println("Enter Doctor ID you want to update:"); 
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
			int idnum = Integer.parseInt(br.readLine()); 
			for(int j=0; j<hm.arl1.size(); j++) { 
				if(idnum == hm.arl1.get(j).doctorID) { 
					System.out.println("Enter 1 to change doctor's name \n 2 to change doctor's phone_no \n "
							+ "3 to change doctor's specialization \n 4 to change doctor's availability  "
							+ "registration fees along with the medical expenses"); 
					int ch = Integer.parseInt(br.readLine()); 
					switch(ch) { 
					case 1: 
						System.out.println("Enter doctor's name:"); 
						d2.doctorName = br.readLine();
						d2.doctorID= hm.arl1.get(j).doctorID; 
						d2.specialization = hm.arl1.get(j).specialization;
						d2.availability = hm.arl1.get(j).availability; 
						hm.arl1.set(j,d2); 
						System.out.println("Doctor updated !!!"); 
						break; 
							case 3: 
								System.out.println("Enter Doctor Phone_no:"); 
								//d2.phone_no = hm.arl1.get(i).phone_no;
								d2.doctorID = hm.arl1.get(j).doctorID; 
								d2.doctorName = hm.arl1.get(j).doctorName;   
								d2.specialization = hm.arl1.get(j).specialization;  
								d2.availability= hm.arl1.get(j).availability; 
								hm.arl1.set(j,d2); 
								System.out.println("Doctor updated !!!"); 
								break; 
								case 4: 
									System.out.println("Enter Doctor Specialization:"); 
									d2.doctorID= hm.arl1.get(j).doctorID; 
									d2.doctorName = hm.arl1.get(j).doctorName; 
									d2.phone_no = hm.arl1.get(j).phone_no; 
									d2.specialization = br.readLine();
									d2.availability = hm.arl1.get(j).availability; 
									hm.arl1.set(j,d2); 
									System.out.println("Doctor updated !!!"); 
									break; 
								case 5: 
									System.out.println("Enter Doctor Availability:"); 
									d2.doctorID= hm.arl1.get(j).doctorID; 
									d2.doctorName = hm.arl1.get(j).doctorName; 
									//d2.phone_no = hm.arl1.get(j).phone_no; 
									d2.specialization = br.readLine();
									d2.availability = hm.arl1.get(j).availability; 
									hm.arl1.set(j,d2); 
									System.out.println("Doctor updated !!!"); 
									break; 
										default: 
											System.out.println("Invalid choice."); 
											break;
											} 
					/*End of switch block */ 
					
					}
				/*End of if block */ 
				}
			/*End of for block */ 
			System.out.println("Do you want to continue updating (y/n):"); 
			l1=(char)br.read(); 
			}
		while(l1=='y'); 
		/*End of do-while block */ 
		}
	/* Function to display patients details*/ 
	void showDoctorDetails() 
	{ 
		System.out.println("Doctor-ID \t Doctor-Name \t\t Age  \t Phone_No  \t specialization  \t availability"); 
		for(int i=0; i<hm.arl1.size(); i++) { 
			System.out.println(hm.arl1.get(i).doctorID + " \t\t "+hm.arl1.get(i).doctorName+" \t\t "
					+ " \t "+hm.arl1.get(i).phone_no+ " \t "+hm.arl1.get(i).specialization+" "
							+ "\t "+hm.arl1.get(i).availability+" \t\t "); }
		}
	}
}
/*** End of Doctor class ******/