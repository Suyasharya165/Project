package snake;

import java.util.Scanner;

public class MyTest {
	

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String word=sc.nextLine();
		int n=sc.nextInt();
		sc.nextLine();
		for(int i=0;i<n;i++)
		{
			String sub=sc.nextLine();
			System.out.println(MyTest.getReport(word,sub));
		}
	}

	private static String getReport(String word, String sub) {
		int m=word.length();
		int n=sub.length();
		
		int i=0,j=0;
		while(j<n&&i<m)
		{
			System.out.println("matching "+word.charAt(i)+" with "+ sub.charAt(j));
			if(word.charAt(i)==sub.charAt(j))
			{
				i++;
				j++;
				System.out.println("matched");
			}
			else
			{
				i++;
				System.out.println("Unmatched");
			}
			
		}
		if(j==n)
			return "POSITIVE";
		else
			return "NEGATIVE";
	}

}